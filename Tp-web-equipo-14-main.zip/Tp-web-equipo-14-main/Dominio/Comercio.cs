﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Comercio
    {
        public string nombre { get; set; }
        public string Direccion { get; set; }
        public int Celular { get; set; }

        
        
    }
}
